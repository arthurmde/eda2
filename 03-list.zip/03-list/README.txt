===== Lista 03 de EDA 2 ========

Alexandre Almeida Barbosa - 10/0006345
Arthur de Moura Del Esposte - 10/0007813


Para compilar o programa utilize o Makefile com a seguinte linha de comando em um ambiente linux:
$ make clean
$ make

Ou se preferir pode compilar manualmente utilizando o seu compilador, seguindo o mesmo realizado no Makefile

para executar:
$ ./prog

este programa contém a resolução e testes criados para as questões 3 da lista 03

O programa principal, arquivo main.cpp, contém a execução de todos os algoritmos de ordenação criados para esta lista. Todos executam a ordenação em um vetor aleatoriamente desordenado.

- Para a questão 3, a execução é realizada pausadamente para que se possa ver o comportamento do algoritmo e suas trocas durante o Merge.