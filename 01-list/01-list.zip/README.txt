===== Lista 01 de EDA 2 ========

Arthur de Moura Del Esposte - 10/0007813
Lucas Kanashiro

Para compilar o programa utilize a seguinte linha de comando em ambiente linux com o compilador g++:

$ g++ -o prog main.cpp Array.cpp CircularArray.cpp -I. -ansi -Wall -pedantic -std=c++0x

para executar:
$ ./prog

este programa contém a resolução e testes criados para as questões 4, 5 e 6 da lista 01

Para as questões 4 e 6 foram utilizada a classe Array
Para a questão 5 foi utilizada a classe CircularArray
Ambas são utilizadas no arquivo main.cpp

